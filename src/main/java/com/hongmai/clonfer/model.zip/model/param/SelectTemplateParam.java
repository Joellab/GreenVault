package com.hongmai.clonfer.model.param;

import lombok.Data;

/**
 * @author JiaweiWang
 * @date 2021/9/13
 * @description
 */
@Data
public class SelectTemplateParam {

    private String title;

    private String code;
}
