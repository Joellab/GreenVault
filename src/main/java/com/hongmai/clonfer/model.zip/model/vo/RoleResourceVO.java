package com.hongmai.clonfer.model.vo;

import java.util.Set;

/**
 * @author JiaweiWang
 * @date 2021/9/12
 * @description
 */
public class RoleResourceVO {

    Set<Integer> resource;
}
