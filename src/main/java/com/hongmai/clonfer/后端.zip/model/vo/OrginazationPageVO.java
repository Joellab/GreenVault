package com.hongmai.clonfer.model.vo;

/**
 * @author JiaweiWang
 * @date 2021/9/9
 * @description
 */
public class OrginazationPageVO {

    private String uuid;

    private String owner;
}
