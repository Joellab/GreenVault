package com.hongmai.clonfer.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.hongmai.clonfer.model.domain.CpBaseRole;

/**
 * @author JiaweiWang
 * @date 2021/9/4
 * @description
 */
public interface RoleService extends IService<CpBaseRole> {

}
