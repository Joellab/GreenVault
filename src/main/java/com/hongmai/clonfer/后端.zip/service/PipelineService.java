package com.hongmai.clonfer.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.hongmai.clonfer.model.domain.CpConferencePipeline;

/**
 * @author JiaweiWang
 * @date 2021/9/13
 * @description
 */
public interface PipelineService extends IService<CpConferencePipeline> {
}
