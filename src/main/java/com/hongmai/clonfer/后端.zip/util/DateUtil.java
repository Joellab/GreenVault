package com.hongmai.clonfer.util;

import java.util.Date;

/**
 * @author JiaweiWang
 * @date 2021/9/4
 * @description
 */
public class DateUtil {

    public static Date getCurrentTime() {
        return new Date();
    }

}
